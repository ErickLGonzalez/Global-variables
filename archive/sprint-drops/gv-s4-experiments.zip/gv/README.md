# Global-variables

**Observational decompilation of physics.** Treat physical law as an unknown rule system; recover its grammar — types, invariants, operators, composition rules — one certified constraint at a time. Constants are conjectured to be invariants of a positive, compositional operator structure 𝕽, not primitive numbers.

Core documents:
- [`docs/constant-atlas-v0.5.md`](docs/constant-atlas-v0.5.md) — constant atlas, restraint matrix, bridge formula, discipline formula, decoding chain (the base algorithm). *(Prior: [v0.4](docs/constant-atlas-v0.4.md), [v0.3](docs/constant-atlas-v0.3.md), [v0.2](docs/constant-atlas-v0.2.md).)*
- [`docs/conjectures-v0.1.md`](docs/conjectures-v0.1.md) — the ten blank-filling conjectures ?₁–?₁₀, each with formalization, test protocol, and falsifier.

## B1 — Truncated moment solver (implemented ✅)

Benchmark B1 of the decoding chain: hidden moments of a finite measure are recovered through positivity + Curto–Fialkow flat extension, with **exact rational certificates**.

Epistemic outcomes (Discipline Formula v0.2):

| Outcome | Meaning | Mechanism |
|---|---|---|
| `FORCED` | uniquely determined | flat extension → exact recurrence, exact recovery |
| `PERMITTED` | constrained to a certified interval | exact-PSD bisection; inner interval certified feasible, outer bracket certified infeasible; unbounded directions reported honestly |
| `REJECTED` | hard constraint violated | exact negative Schur pivot as witness |

Design guarantees:
- All positivity/rank/forcing claims use **exact `Fraction` arithmetic** (the Schur pivots generalize the `G00 > 0`, `S2 = G22 − G02²/G00 > 0` verifier standard).
- Numerics are **quarantined** to atom extraction only, with an audited residual against the exact moments reported in the certificate.
- `Score = ∞` on any violated **or uncertified** hard constraint — uncertified ≠ pass.

Run:
```bash
python3 tests/test_b1.py
```
Output: 4/4 tests pass; JSON certificate written to `certificates/b1_certificate.json`.

```
b1_moment_solver/
  exact.py        exact Hankel matrices, PSD certificates, rank, flat-extension recurrence
  recover.py      forced-tail recovery, permitted intervals, audited atom extraction
  certificate.py  forced/permitted/free/rejected JSON certificate format
tests/test_b1.py  T1 forced · T2 permitted · T3 rejected (negative control) · T4 atom audit
```

## B4 — Area theorem as gravity's composition law (implemented ✅, REAL mode)

Benchmark B4 tests conjecture **?₃**: A_f ≥ A₁ + A₂ under merger, via the dimensionless invariant η_A = (A_f − A₁ − A₂)/A_f. Certificate class: **STATISTICAL** (Monte Carlo + exact Clopper–Pearson binomial lower bound) — deliberately distinct from B1's exact-rational class.

```bash
python3 tests/test_b4.py          # DEMO regression
python3 scripts/run_b4_real.py    # REAL mode (see data/README.md)
```

**REAL results** (official posteriors; certificate `certificates/b4_certificate.json`, mode REAL):
GW250114 → SUPPORTED (P_lower 0.99977, η_A ≈ 0.366) · GW150914 → SUPPORTED (P_lower 0.99862, η_A ≈ 0.363). Final-state provenance in these PE releases is NR-fit (ringdown columns absent); loader still auto-prefers ringdown keys when present. Edit-001 apply conditions are checked; atlas bump to v0.3 remains for the promotion pass.

Demo regression (reconstructed summary-statistic posteriors): GW150914 / GW250114 SUPPORTED; GW190521 / GW190814 INCONCLUSIVE **by design**; falsifier injection → VIOLATION_CANDIDATE.

```
b4_area_pipeline/
  kerr.py       Kerr horizon area, η_A invariant
  remnant.py    validated nonspinning NR fits (cross-check layer only)
  demo_data.py  published summary stats, provenance-flagged
  pipeline.py   MC test, exact binomial bounds, statistical certificate
  loader.py     GWOSC/PESummary HDF5 loader (REAL mode, ringdown-preferred)
```

## B2 — Qubit process completion via Choi positivity (implemented ✅)

Extends the exact-rational certificate class to **Gaussian-rational Hermitian matrices** (`cexact.py`) and demonstrates **restraint stacking** — the atlas mechanism — on a finite quantum process:

| Restraints active | Hidden Choi entry | Outcome |
|---|---|---|
| PSD alone | diagonal of rank-2 mixed channel | PERMITTED — certified interval [1/9, ∞) |
| PSD + trace preservation | same entry | **FORCED** to exact truth (1) |
| PSD + rank-1 (pure process) | complex off-diagonal | **FORCED** to −12i/25 exactly (flat-extension analogue) |

Plus exact CPTP audit (Choi's theorem as the gate) and a negative control (corrupted Choi rejected with exact witness pivot). Run: `python3 tests/test_b2.py` — 5/5 pass, certificate in `certificates/b2_certificate.json`.

## B3 — Electroweak closed system (implemented ✅)

Benchmark B3 runs the decoding chain on tree-level electroweak structure. Pseudo-data for `(e, g, g′, θ_W, M_W, M_Z, v, G_F)` is presented as an unlabeled exact-Fraction table; the engine must *discover* the relations by template forcing (same epistemic class as B1/B2) and report **d_identifiable = 3**.

```bash
python3 tests/test_b3.py
```

Results (5/5):
- Headline relations found: `e = g sinθ_W`, `M_W = gv/2`, `M_Z = (v/2)√(g²+g′²)`, `G_F = 1/(√2 v²)` (√2 certified via `1/G_F² = 2 v⁴`)
- Exact Jacobian rank over ℚ: n=9, rank=6 → **d_identifiable = 3**
- FREE basis recovered: `{g, g′, v}`; forced: `{e, sinθ_W, cosθ_W, M_W, M_Z, G_F_inv_sq}`
- Held-out `M_Z` predicted exactly from the free basis; corrupted `e` breaks R1/R2/R9 (negative control)

```
b3_electroweak/
  exact.py        Fraction helpers, Pythagorean Weinberg angle
  pseudo_data.py  closed-system generator from free basis (g, g′, v)
  relations.py    exact template discovery (R1–R9)
  rank.py         Jacobian rank → d_identifiable
  graph.py        FREE/FORCED dependency labels
  discover.py     end-to-end pipeline
```

## B5 — Cluster / multi-channel factorization (?₅ → H) (implemented ✅)

Benchmark B5 is the B3 extension named in conjecture ?₅: 2→2 and 2→4 toy channels with exact-Fraction amplitudes. The engine must discover that **one coupling** controls all factorization residues (`R_24 = A_22²`) and reject channel-dependent couplings.

```bash
python3 tests/test_b5.py
```

Results (5/5): factorization identities hold; **d_identifiable = 1**; falsifier FAIL as required. Atlas edit-002 promotes gauge Cmp (?₅) → **H** for α, α_s, and the electroweak block.

```
b5_cluster/
  exact.py        Fraction helpers
  pseudo_data.py  local vs channel-dependent counterexample tables
  relations.py    factorization template discovery (F1–F6)
  rank.py         Jacobian rank → d_identifiable
  discover.py     end-to-end pipeline
```

## B6 — 2D QNEC as Schur-pivot positivity (?₂ → P) (implemented ✅)

Benchmark B6 places the strengthened 2D QNEC inside the certified verifier: `2π⟨T⟩ ≥ S'' + (6/c)(S')²` **⇔** PSD of `M = [[c/6, S'], [S', 2πT − S'']]`. Saturation ⇔ rank-1 flat boundary (same structure B1 uses for forcing).

```bash
python3 tests/test_b6.py
```

Results (5/5): 500-case equivalence audit; vacuum saturation (pivot exactly 0); coherent-state strictness; thermal symbolic identity; negative control (witness pivot −1/12). Atlas edit-003 promotes G Pos (?₂) → **P (H-track)**. Epistemic scope: exact reformulation + certified instances — not a new QNEC proof; GNS realization of M remains open for H.

```
b6_qnec/
  qnec.py   matrix, Schur pivot, vacuum / coherent / thermal / falsifier instances
```

## B7 — Onsager transport-matrix completion (implemented ✅)

Benchmark B7 (seeded by R15) exercises restraint stacking on **effective coefficients**: near-equilibrium transport `J = L X` with `L ⪰ 0` (second law) and `L = Lᵀ` (Onsager reciprocity).

```bash
python3 tests/test_b7.py
```

Results (5/5): ground-truth PD+symmetric; PSD alone → PERMITTED; +reciprocity → FORCED; second-law and reciprocity falsifiers rejected. Certificate: `certificates/b7_certificate.json`.

```
b7_onsager/
  exact.py         Fraction helpers
  pseudo_data.py   thermoelectric L, hide/corrupt
  complete.py      PSD audit, reciprocity forcing, permitted intervals
```

## Atlas edits

- [edit-001](docs/atlas-edits/edit-001-conjecture3-promotion.md) — **?₃ → P (H-track)** (atlas v0.3)
- [edit-002](docs/atlas-edits/edit-002-conjecture5-promotion.md) — **?₅ → H** (atlas v0.4)
- [edit-003](docs/atlas-edits/edit-003-conjecture2-qnec.md) — **?₂ → P (H-track)** (atlas v0.5)

## B8 — Blind grammar identification (implemented ✅) & Atlas Engine v0.1 (implemented ✅)

**B8** (6/6): identifies Hamiltonian / gradient-flow / GENERIC / quantum grammars from unlabeled data using *only similarity-invariant signatures* (spectra, conserved forms — R15 canonicalization enforced). Honest verdict structure: exactly-zero damping is never certifiable, so the conservative verdict is **HAMILTONIAN_WITHIN_BOUND** with a certified damping bound; the drift test both *detects* damping below the spectral noise floor (ε=3e-4 → GENERIC) and bounds it when undetectable (ε=1e-5 inside the bound, no over-claim). Quantum grammar split is exact via Choi rank (B2). Two estimator lessons recorded as stipulations: forward-difference estimation injects artificial damping ~dt·ω²/2 (rejected for propagator+matrix-log), and SVD sign must be canonicalized before drift direction is physical.

**Atlas Engine v0.1** (5/5): the restraint matrix as a constraint-satisfaction object. Eight theorem-anchored implication rules (GNS, cluster decomposition, dispersion positivity, KMS, anomaly cancellation, GSL-composition, Schur-QNEC, dS-entropy) propagate to fixpoint: **7 machine-derived candidate upgrades** — Cmp ?→P for λ_H/Yukawa/neutrino/θ_QCD, Top ?→P for Yukawa/neutrino (weak ?₆), Λ Pos ?→P (weak ?₇) — each with full derivation chains, pending human edit records (the engine cannot mint H). Two findings: the Sym column conflates internal/spacetime symmetry (v0.6 item), and B6 puts gravity's Uni="—" under formal tension. ?₁ and ?₄ remain untouched — genuinely open, as they must be. Certificates: `certificates/b8_certificate.json`, `certificates/atlas_engine_certificate.json`.

**Sprint work orders:** [`docs/sprint-specs-v1.md`](docs/sprint-specs-v1.md) — full computational specs for S1 (ratify engine pass → atlas v0.6), S2 (GNS for ?₂→H, free-fermion route), S3 (PDG layer for B5), S4 (?₇ dS rank saturation — heavy compute), S5 (B7 Kelvin-relation real data), plus a standing rule: every sprint adds ≥1 theorem rule to the engine and re-propagates.

## B9 — Circuit decompilation: the 2025 Nobel methodology as gates (implemented ✅)

Benchmark built from the Clarke–Devoret–Martinis paper chain (ledger **R16–R22**, verbose provenance traces). The linearized RCSJ circuit in canonical flux–charge coordinates is exactly our GENERIC grammar (W fixed by circuit topology, M = conductance block, FDT noise), and B9 (6/6) executes the Nobel recipe as certified gates: **T1** M, W recovered to ≤2% via the equilibrium estimator K = −J_b·H_V⁻¹ with PSD + FDT certificates; **T2** hidden bath REJECTED by the FDT audit; **T3 (headline)** the *Gibbs circularity* — on the same corrupted data, spectroscopy-route calibration rejects at residual 0.49 while trajectory-self-consistent calibration passes at 0.02, proving independent calibration is the degeneracy-breaking ingredient (the Voss–Webb ambiguity and its Berkeley resolution, computationally reproduced; calibration ROUTE now a mandatory certificate field); **T4** model-order inversion (1D mobility = 1/G vs 2D M entry = G) demonstrated and stipulated; **T5** the effective-temperature shortcut is a certified gate failure; **T6** exact rational charge-basis Hamiltonian passes the 1985-style parameter-free held-out spectroscopy test (E01 within 0.31% of the independent asymptotic). Full analysis + cross-agent comparison: [`docs/notes/nobel2025-circuit-decompilation.md`](docs/notes/nobel2025-circuit-decompilation.md).

## S2 state layer — microscopic verification for the ?₂ GNS program (implemented ✅)

Complement to the S2 operator probe (5/5, `tests/test_s2_state_layer.py`): free Dirac chain with exact Gaussian kernels populates the B6 matrix **from data** — central charge blind-extracted (c_fit = 1.0001), vacuum flat-boundary saturation (|Q|/|S″| = 0.001 at ℓ=30), thermal coth identity matching the energy density to 1.9%, entanglement first law exact to 0.00% with textbook 4.00× ε-scaling, positivity gate armed. **Diagnostic result of running both layers:** the probe's operator mismatch is now *localized* — state machinery sound, operator ansatz missing the Casini–Huerta **bilocal term** (Eisler–Peschel on the lattice). Next construction (S2-b) specced in the note addendum: exact vacuum kernel `modular_1p` as the fixed GNS operator over the coherent orbit. ?₂ stays P — no premature promotion.

## S2-b — exact-kernel GNS probe (implemented ✅, 6/6)

Fixed vacuum kernel (`modular_1p`) tested over the boosted coherent orbit: dual-route relative entropy agrees to **0.00%** with exact quadratic scaling (4.00); ΔS = 0 to 5.5e-14 (orbit gate); **capacity = entropy verified to 0.1%** — the first second-moment Gram entry (ω(K²)−ω(K)² = the entropy slot); scrambled same-spectrum kernel fails by 206% (success is structural). Kernel anatomy quantified: edge-local (≤6.6% vs −πβ(x)), bulk plateau at 0.46×, long-range fraction 0.235 (Eisler–Peschel). **Erratum filed:** single-interval continuum K is local; CH bilocal is multi-interval. **Mismatch diagnosis complete:** the old probe's cut-bond A₁ is precisely where long-range terms bite; smooth probes pass even locally (sum rule). ?₂ stays P; edit-007 first-moment box ticks.

## S3 — one α_s across channels and scales (implemented ✅, 5/5, REAL data)

The B5 empirical layer: four independent extractions (τ decays @ 1.777 GeV, EW fit, lattice, tt̄ @ M_Z) under 2-loop RG with m_b threshold matching. Results: the 51× span closes at **0.09σ** (0.1180 @ M_Z → 0.3133 @ m_τ vs 0.312±0.015); combined **α_s(M_Z) = 0.1186 ± 0.0009, χ²/dof = 0.11** — d_identifiable = 1 on real data; **no-running null rejected at ~13σ** (asymptotic freedom certified by our own pipeline); Score(d=1) = 2.33 beats Score(d=4) = 8.00; skipping threshold matching shifts results by 2.7× the error (M-layer, quantified). World average used only as a non-input cross-check (no Gibbs-style circularity). Memo: `docs/atlas-edits/edit-008-s3-empirical-note.md`.

## S4 — ?₇ rank saturation + the information-Gram refinement (implemented ✅, 5/5)

dS₂ static patch as a thermal Dirac chain (β = 2πℓ) with the horizon as a redshift weight. **?₇-weak CONFIRMED:** weighted Gram rank saturates (e.g. 37/37/37 at ℓ=4) while the unweighted control grows unboundedly — a horizon effect with the falsifier live. **Naive ?₇-strong FAILS honestly:** kinematic rank counts accessible modes (∝ ℓ). **Refinement discovered:** the INFORMATION Gram D·C(1−C)·D has saturated rank **exactly ℓ-independent (18, 18, 18, 18 across ℓ = 4→32)** and ∝ ln(1/ε) — rank tracks entropy for the information Gram; ?₇ must specify which Gram. Compression certificate: rank-67 forces all 384² entries to 6.4e-7 (flat-extension reading). `certificates/s4_certificate.json`.

## Experimental program — BEC / frontier interferometry (R23–R24, filed)

[`docs/notes/experimental-program-bec.md`](docs/notes/experimental-program-bec.md): the Howl–Fuentes frequency-interferometry architecture + Tino-group trapped-Sr platform = a **coupling-matrix machine** whose every reconstructed layer already has a certification back-end here (Choi→B2, susceptibility→B7, M/W/σ→B9 with FDT gate, classification→B8, QFIM→Pos). Five experiments mapped to matrix cells with tier labels (BENCHMARK / ANALOGUE-REAL / FUNDAMENTAL-REAL — only the third can change a cell); cross-agent review: skeleton adopted, two tier violations corrected (no G/Λ primary cells for a BEC classifier), three missing disciplines injected (FDT gate, calibration route, information-Gram refinement), plus the zero-hardware **EXP-D**: the live >5σ Rb–Cs α tension run through the S3 pipeline. Queue: B10 (CV-channel completion), B11 (composition classifier), S3-EM.

## Research library

[`docs/references.md`](docs/references.md) — research-paper ledger. **R15** Chen et al. 2024 + [addendum](docs/notes/r15-addendum-cross-agent-review.md): constraint-native generators, canonicalization / distill-before-score rules, **B7 done**, **B8 queued** (blind grammar identification). **R14** Maudlin: M-layer stipulations + arrival-time track. Notes: [`onsager-sonsagernet-chen2024.md`](docs/notes/onsager-sonsagernet-chen2024.md), [`measurement-interface-maudlin.md`](docs/notes/measurement-interface-maudlin.md).

## Roadmap (proposed next steps)

**Immediate (next session):**
1. **B8** — blind grammar identification (Hamiltonian vs Onsager/GENERIC vs CPTP); AMBIGUOUS when underdetermined; cross-grammar falsifiers.
2. **?₂ → H** — GNS realization: exhibit operators/state with ω(A_i†A_j) = M_ij.
3. **?₇** — toy-dS rank-saturation study (B1 is the engine).

**Near-term:**
4. **PDG layer for B5** — replace toy channels with held-out empirical cross-section ratios.
5. Unification of GSL / area theorem (?₂ + ?₃ toward joint H).
6. **Arrival-time track** (queued from R14) — catalogue rival predictions + falsifier before any experiment.
7. Empirical thermoelectric layer for B7 (Seebeck/Peltier / Kelvin relation).
8. **?₁** — causal-thermal toy model; **?₄/?₈/?₉** functional-RG modeling; **?₆** index-theoretic flavor search (long horizon).

## Discipline

Every `?` is a **prediction with a falsifier**, never evidence for the synthesis that produced it. Promotion requires: all hard constraints certified · ≥2 domains from one 𝕽 · d_identifiable strictly reduced · survival on held-out **domains** · ≥1 novel blind-tested prediction.
